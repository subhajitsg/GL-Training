package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String line="I am working with Global Logic in Noida";
		int i=0;
		line=line+" ";
		while(i<line.length()) {
			int k=line.indexOf(' ',i);
			if(k!=-1) {
				System.out.println(line.substring(i,k));
				i=k+1;
			}
		}
		
	}

}
