package DAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excl_operations {
	public void write_excel(ArrayList<student> std1) {
		int row=1;
		try {
			File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\Book2.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			for(student s1: std1)
			{
			XSSFRow r=sh.getRow(row);
			XSSFCell c=r.createCell(4);
			c.setCellValue((double)s1.avg);
			row++;
			}
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	}
	public ArrayList<student> read_excel() {
		
		ArrayList<student> std_al=new ArrayList<student>();
		
		
	try {
		File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\Book2.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		int first_row=sh.getFirstRowNum();
		int last_row=sh.getLastRowNum();
		int nor=last_row-first_row;
		for(int i=1;i<=nor;i++)
		{
		student s=new student();
		XSSFRow r=sh.getRow(i);
		XSSFCell c=r.getCell(0);
		s.rollno=(int)c.getNumericCellValue();
		
		XSSFCell c1=r.getCell(1);
		s.name=c1.getStringCellValue();
		
		XSSFCell c2=r.getCell(2);
		s.java=(int)c2.getNumericCellValue();
		
		XSSFCell c3=r.getCell(3);
		s.selenium=(int)c3.getNumericCellValue();
		System.out.println(s);
		s.average();
		std_al.add(s);
		}
	} catch (FileNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (IOException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	}
	
	return std_al;

	}

}
