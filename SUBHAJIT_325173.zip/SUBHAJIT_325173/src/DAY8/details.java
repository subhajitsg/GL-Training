package DAY8;

public class details {
	int slno;
	String passname;
	String from;
	String to;
	int rate;
	int no_seats;
	int total;
	
	public int cal() {
		this.total=this.rate*this.no_seats;
		return total;
	}
	
}
