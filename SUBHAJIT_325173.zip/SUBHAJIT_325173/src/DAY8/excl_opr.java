package DAY8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excl_opr {
	public ArrayList<details> read_excl(){
		ArrayList<details> psg=new ArrayList<details>();
		try {
			File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\Book4.xlsx");
			FileInputStream fs=new FileInputStream(f);
			XSSFWorkbook xw=new XSSFWorkbook(fs);
			XSSFSheet sh=xw.getSheet("Sheet1");
			int firstrow=sh.getFirstRowNum();
			int lastrow=sh.getLastRowNum();
			int r1=lastrow-firstrow;
			for(int i=1;i<=r1;i++) {
				details d=new details();
				XSSFRow r=sh.getRow(i);
				XSSFCell c=r.getCell(0);
				d.slno=(int)c.getNumericCellValue();
				
				XSSFCell c1=r.getCell(1);
				d.passname=c1.getStringCellValue();
				
				XSSFCell c2=r.getCell(2);
				d.from=c2.getStringCellValue();
				
				XSSFCell c3=r.getCell(3);
				d.to=c3.getStringCellValue();
				
				XSSFCell c4=r.getCell(4);
				d.rate=(int)c4.getNumericCellValue();
				
				XSSFCell c5=r.getCell(5);
				d.no_seats=(int)c5.getNumericCellValue();
				
				System.out.println(d);
				d.cal();
				psg.add(d);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return psg;
	}
	public void write_exl(ArrayList<details>d1) {
		int row=1;
		
		try {
			File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\Book4.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			for(details d2:d1) {
				XSSFRow r=sh.getRow(row);
				XSSFCell c=r.createCell(6);
				c.setCellValue(d2.total);
				row++;
			}
			FileOutputStream fo=new FileOutputStream(f);
			wb.write(fo);
			}
		 catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
	}
}
