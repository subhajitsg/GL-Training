package DAY8;

import java.util.ArrayList;

public class ex_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		excl_opr ex=new excl_opr();
		ArrayList<details> d5=new ArrayList<details>();
		d5=ex.read_excl();
		ex.write_exl(d5);
	}

}
