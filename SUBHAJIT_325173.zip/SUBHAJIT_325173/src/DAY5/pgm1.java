package DAY5;



public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=10,m=0,p;
		int a[]= {1,2,3};
		try {
		p=n/m;
		System.out.println(p);
		System.out.println(a[2]);
		}
		catch(ArithmeticException e) {
			System.out.println("In Airthmetic exception");
		}
		catch(ArrayIndexOutOfBoundsException ea) {
			System.out.println("in Out of Bound Exception");
		}
		catch(Exception eq) {
			System.out.println("Any other Exception");
		}
		
		System.out.println("outside catch block");
	}

}

