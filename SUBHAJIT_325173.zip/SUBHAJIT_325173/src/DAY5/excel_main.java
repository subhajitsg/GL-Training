package DAY5;

public class excel_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		excl_operations ex= new excl_operations();
		for(int i=1;i<=2;i++) {
		student s1=ex.read_excel(i);
		
		s1.average();
		ex.write_excel(s1,i);
		}
	}

}
