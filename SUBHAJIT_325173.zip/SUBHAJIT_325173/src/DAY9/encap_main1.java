package DAY9;

public class encap_main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encap1 en=new encap1();
		en.setAccno(30456789);
		en.setAccbal(36304);
		System.out.println("Account No: "+en.getAccno()+"\nAccount bal: "+en.getAccbal());
	}

}
