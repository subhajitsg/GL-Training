package DAY9;

public class bank_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		bank b;
		b=new citibank();
		System.out.println("Citibank ROI: "+b.roi());
		b=new axis();
		System.out.println("Axis ROI: "+b.roi());
	}

}
