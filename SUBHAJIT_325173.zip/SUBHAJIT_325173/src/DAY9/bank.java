package DAY9;

public class bank {
	public float roi() {
		return 0f;
		
	}
	public void show() {
		System.out.println("Bank details");
	}
	
}
