package DAY9;

public class axis extends bank {
	public float roi() {
		return 8.2f;
	}
}
