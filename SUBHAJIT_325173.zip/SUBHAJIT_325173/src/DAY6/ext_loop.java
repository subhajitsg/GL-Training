package DAY6;

public class ext_loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str[]= {"Noida","GlobalLogic","Delhi","Sector 41"};
		for(String s:str) {
			System.out.println(s);
		}
	}

}
