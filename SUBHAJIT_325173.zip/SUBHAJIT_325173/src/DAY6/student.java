package DAY6;

public class student {
	public int rollno;
	public String name;
	public int java;
	public int selenium;
	public float avg;
	
	public student(String name,int rollno,int selenium,int java)
	{
		this.name=name;
		this.rollno=rollno;
		this.selenium=selenium;
		this.java=java;
		this.average();
	}
	
	public void average()
	{
		 this.avg=(this.java+this.selenium)/2.0f;
		 
	}
}
