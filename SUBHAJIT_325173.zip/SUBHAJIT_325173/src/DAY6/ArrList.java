package DAY6;

import java.util.ArrayList;

public class ArrList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> str_al=new ArrayList<String>();
		
		str_al.add("Xiaomi");
		str_al.add("K20");
		System.out.println("Printing the entire string together: "+str_al);
		//System.out.println(str_al.get(0));
		
		//Or
		
		for(String s:str_al) {
			System.out.println(s);
			
		}
		str_al.add(1,"Redmi");
		System.out.println("Insertion at index: "+str_al);
		str_al.remove("K20");
		System.out.println("After removal: "+str_al);	
		str_al.add("K20 Pro");
		System.out.println(str_al);
	}

}
