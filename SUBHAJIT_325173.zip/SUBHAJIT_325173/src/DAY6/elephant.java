package DAY6;

public class elephant extends animal {
	int lot;
	int lotusks;
	
	public void swim() {
		System.out.println("Elephant swims");
	}
	
	public void spraying() {
		System.out.println("Elephant sprays using trunks");
	}
	public void acts() {
		System.out.println("This Elephant acts");
	}
	
		
	public elephant(int lot, int lotusks) {
		// TODO Auto-generated constructor stub
		this.lot=lot;
		this.lotusks=lotusks;
		spraying();
		acts();
		swim();
	}


	public void display() {
		System.out.println("Name: "+this.name +"\nNo of legs: " +this.nol + "\nSkin color: "+ this.color + "\nFood: " + this.food 
							+ "\nGender: " + this.gender + "\nAge: " + this.age );
		
		System.out.println("Length of trunk : "+ this.lot + "\nLength of tusks: " + this.lotusks);
	}
}
