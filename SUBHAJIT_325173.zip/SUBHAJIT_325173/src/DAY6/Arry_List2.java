package DAY6;

import java.util.ArrayList;

public class Arry_List2 {
	ArrayList<student> std_al=new ArrayList<student>();
	public void create_al()
	{
		student s1=new student("Ramesh",101,80,90);
		student s2=new student("Ramesh1",102,85,95);
		std_al.add(s1);
		std_al.add(s2);
	}
	public void display_al()
	{
		for(student s:std_al)
		{
			System.out.println("Name: "+s.name+" Rollno:"+s.rollno+" Selenium:"+s.selenium+" Java:"+s.java+" Average:"+s.avg);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Arry_List2 al=new Arry_List2();
		al.create_al();
		al.display_al();
		
	}

}
