package DAY6;

public class animal {
	int nol;
	String color;
	String food;
	String name;
	String gender;
	int age;
	
	
	
	public void eats()
	{
		System.out.println("The animal eats : "+food);
	}
	public void walks()
	{
		System.out.println("The animal walks");
		
	}
	public void runs() {
		System.out.println("The animal runs");
	}
	public void display()
	{
		System.out.println("No of the legs : "+this.nol+"\n Skin Color : "+this.color+"\nFood "+this.food+"\nName : "+this.name);
		
	}
}
