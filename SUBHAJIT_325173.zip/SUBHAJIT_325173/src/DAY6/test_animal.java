package DAY6;

public class test_animal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		elephant e1=new elephant(7,6);
		elephant e2=new elephant(6,5);
		e1.age=28;
		e1.color="Black";
		e1.food="Tree bark";
		e1.gender="male";
		e1.name="Jadoo";
		e1.nol=4;
		e1.eats();
		e1.walks();
		e1.runs();
		e1.display();
		
		
		e2.age=33;
		e2.color="Black";
		e2.food="twigs";
		e2.gender="male";
		e2.name="Jumbo";
		e2.nol=4;
		e1.eats();
		e1.walks();
		e1.runs();
		e2.display();
		
		
		tiger t1=new tiger(6,7);
		tiger t2=new tiger(7,9);
		t1.age=24;
		t1.color="Red-Orange";
		t1.food="Deers";
		t1.gender="male";
		t1.name="Shere khan";
		t1.nol=4;
		e1.eats();
		e1.walks();
		e1.runs();
		t1.display();
		
		
		t2.age=24;
		t2.color="White";
		t2.food="Fishes";
		t2.gender="male";
		t2.name="Richard Parker";
		t2.nol=4;
		e1.eats();
		e1.walks();
		e1.runs();
		t2.display();
	}

}
