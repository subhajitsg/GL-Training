package DAY2;



public class pgm11 {
	public static boolean isprime(int n) {
		int i;
		boolean flag=true;
		for(i=3;i<=n/2;i++) {
			if(n%i==0) {
				flag=false;
				break;
			}
		}
		return flag;
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=11,c=1,sum=0;
		boolean b;
		while(c<=10)
		{
			b=isprime(n);
			if(b==true) {
				sum=sum+n;
				c++;
			}
			n++;
		}
		System.out.println(sum);
		
	}

}
