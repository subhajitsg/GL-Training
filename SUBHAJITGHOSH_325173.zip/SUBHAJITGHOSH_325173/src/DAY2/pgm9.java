package DAY2;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j=4,sum=0;
		for(i=5;i<=9;i++) {
			sum=i*j;
			System.out.println(i+"*"+j+"="+sum);
			j=j+2;
		}
	}

}
