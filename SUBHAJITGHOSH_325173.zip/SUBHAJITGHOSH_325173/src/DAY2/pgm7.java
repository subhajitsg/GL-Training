package DAY2;
import java.util.Scanner;
public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,t,sum=0;
		Scanner sc= new Scanner(System.in);
		n=sc.nextInt();
		while(n!=0)
		{
			t=n%10;
			n=n/10;
			if(t>5)
			{
				sum=sum+t;
			}
		}
		System.out.println("Sum: "+sum);
		sc.close();
	}

}
