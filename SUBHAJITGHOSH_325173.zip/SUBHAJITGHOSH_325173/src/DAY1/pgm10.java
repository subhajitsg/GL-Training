package DAY1;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch='A';
		char c='S';
		//For Scanner input of char we use sc.next.charAt(0);
		if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' || ch=='A' || ch=='E' || ch=='O' || ch=='U' )
		{
			System.out.println("It is a Vowel");
			
		}
		else
		{
			System.out.println("It is not a Vowel");
		}
		
		if(c=='a' || c=='e' || c=='i' || c=='o' || c=='u' || c=='A' || c=='E' || c=='O' || c=='U' )
		{
			System.out.println("It is a Vowel");
			
		}
		else
		{
			System.out.println("It is not a Vowel");
		}
		
	}

}
