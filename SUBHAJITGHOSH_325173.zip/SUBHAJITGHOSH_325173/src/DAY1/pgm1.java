package DAY1;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0,n=0,i=1,j=1,sum=0;
		while(n<10)  
		{  
			j=1;  
			c=0;  
			while(j<=i)  
			{  
				if(i%j==0)  
					c++;  
				j++;   
			}  
			if(c==2)  
			{  
				System.out.println(i);
				sum=sum+i;
				n++;  
			}  
			i++;  
		}
		System.out.println("Sum is : " +sum);
	}
}
