package DAY1;
import java.util.Scanner;
public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float marks;
		float a,b,c;
		Scanner sc=new Scanner(System.in);
		a=sc.nextFloat();
		b=sc.nextFloat();
		c=sc.nextFloat();
		marks=((a+b+c)/3);
		if(marks>=60) {
			System.out.println("First Class "+marks);
		}
		else if(marks>=50 && marks<60) {
			System.out.println("Second Class "+marks);
		}
		else if(marks>=35 && marks<50) {
			System.out.println("Pass Class "+marks);
		}
		else {
			System.out.println("Fail "+marks);
		}
			
	}

}
