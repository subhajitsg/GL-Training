package DAY1;
import java.util.Scanner;
public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c;
		Scanner sc= new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		c=sc.nextInt();
		if(a>b && a>c) {
			System.out.println(a+ " is greater");
		}
		else if(b>c && b>a) {
			System.out.println(b+ " is greater");
		}
		else {
			System.out.println(c+ " is greater");
		}
	}

}
