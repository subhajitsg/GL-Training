package DAY1;
import java.util.Scanner;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n,sum=0,t,z;
		n=sc.nextInt();
		z=n;
		while(n>0)
		{
			t=n%10;
			n=n/10;
			sum=sum*10+t;
		}
		System.out.println(sum);
		if(z==sum)
			System.out.println("Palindrome");
		else
			System.out.println("Not a Palindrome");
		
	}

}
