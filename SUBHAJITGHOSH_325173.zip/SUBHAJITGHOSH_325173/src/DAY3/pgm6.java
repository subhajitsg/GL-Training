package DAY3;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Noida", s2="Noida", s3="noida", s4="I am learning java";
		int l;
		l=s1.length();
		System.out.println(l);
		int r=s1.compareTo(s2);
		int r1=s1.compareToIgnoreCase(s3);
		System.out.println(r);
		System.out.println(r1);
		s3=s4.substring(3,8);
		System.out.println(s3);
		int l1=s4.indexOf("a");
		System.out.println(l1);
		int l2=s4.indexOf("z", 3);
		System.out.println(l2);
	}

}
