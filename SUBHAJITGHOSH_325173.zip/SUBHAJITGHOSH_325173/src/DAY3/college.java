package DAY3;

public class college {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1=new student();
		student priya=new student();
		s1.rollno=13;
		s1.name="Subhajit";
		s1.m1=95;
		s1.m2=99;
		priya.rollno=52;
		priya.name="Priya";
		priya.m1=85;
		priya.m2=89;
		s1.average();
		priya.average();
		System.out.println(s1.rollno);
		System.out.println(s1.name);
		System.out.println(s1.m1);
		System.out.println(s1.m2);
		System.out.println(s1.avg);
		System.out.println(s1.rollno);
		System.out.println(priya.name);
		System.out.println(priya.m1);
		System.out.println(priya.m2);
		System.out.println(priya.avg);
	}

}
