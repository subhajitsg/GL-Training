package DAY3;

public class pgm2 {
	public static int checkeven(int num) {
		if(num%2==0) {
			return num;
		}
		else
			return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		int num[]= {21,34,91,59,16,25,29,74,49,82};
		for(int i=0;i<10;i++)
		{
			sum=sum+checkeven(num[i]);
		}
		System.out.println("The sum of even numbers = " +sum);
	}

}
