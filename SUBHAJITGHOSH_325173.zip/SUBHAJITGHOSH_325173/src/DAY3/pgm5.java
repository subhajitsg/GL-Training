package DAY3;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="My Laptop is ProBook";
		int c=0,p=0;
		while(p!=-1) {
			p=a.indexOf(" ",p+1);
			c++;
		}
		System.out.println("Number of spaces:"+c);
	}

}
