package DAY3;

public class student {
	int rollno;
	String name;
	int m1,m2;
	float avg=0;
	public void average() {
		this.avg=(m1+m2)/2;
	}
}
