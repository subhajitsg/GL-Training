package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class test1 {
	login_page lp;
	home_page hp;
	WebDriver dr;
	
	@BeforeClass
	public void bc() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		lp=new login_page(dr);
		hp=new home_page(dr);
		//cp=new cart_page(dr);
		
	}
	@Test
	public void t1() {
		lp.do_login("standard_user","secret_sauce");
		hp.add_to_cart(1);
		//String x=hp.get_prod_name(1);
		//hp.get_prod_price(1);
		hp.click_cart();
		String y=dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
		/*if(x.equals(y)) {
			System.out.println("Successful");
		}else
			System.out.println("Unsuccessful");*/
		 SoftAssert sa=new SoftAssert();
		//  sa.assertEquals(x, y);
		  
	//	  System.out.println("act_res1: "+x);
		  sa.assertAll();
	}
	
}
