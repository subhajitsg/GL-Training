package PKG_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import main.java.cancel_page;
import main.java.cart_page;
import main.java.home_page;
import main.java.login_page;
import main.java.placeorder;
import main.java.product_page;

public class NewTest {
	login_page lp;
	home_page hp;
	cart_page cp;
	product_page pp;
	WebDriver dr;
	placeorder po;
	cancel_page cp1;
	@BeforeClass
	public void bc() {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get("https://www.Flipkart.com");
		dr.manage().window().maximize();
		lp=new login_page(dr);
		hp=new home_page(dr);
		cp=new cart_page(dr);
		pp=new product_page(dr);
		po=new placeorder(dr);
		cp1=new cancel_page(dr);
	}
	
	
	@Test
	public void t() {
		lp.login("8017127577","chikky1997");
		hp.search();
		pp.click_rate();
		pp.add_to_cart();
		/*  String hnd=dr.getWindowHandle();
     for(String handle:dr.getWindowHandles()) {
   	  dr.switchTo().window(handle);
     }*/
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

		
		/*   ArrayList<String> tabs2 = new ArrayList<String> (dr.getWindowHandles());
		    dr.switchTo().window(tabs2.get(0));*/
		cp.add_to_cart1();
		po.placeorder1();
		po.delivery();
		cp1.cancel();
		/*  hp.click_cart();
		 String s= cp.verify();
		 System.out.println(s);	
		 SoftAssert sa=new SoftAssert();
			sa.assertEquals(s,"");
			sa.assertAll();*/
	}
	


}
