package main.java;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class placeorder {
	WebDriver dr;
	public placeorder(WebDriver dr) {
		this.dr=dr;
	}
public void placeorder1() {
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("abc");
	dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div[2]/div/div[1]/div[1]/div[3]/div/form/button")).click();
}
public void delivery() {
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	dr.findElement(By.xpath("//*[@id=\"CNTCT945144FE75EB437A92F34EBBC\"]/button")).click();
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	dr.findElement(By.xpath("//*[@id=\"to-payment\"]/button")).click();
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[3]/div/label[4]")).click();
	try {
		Thread.sleep(30000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[3]/div/label[4]/div[2]/div/div/div[2]/form/button")).click();
}

}
