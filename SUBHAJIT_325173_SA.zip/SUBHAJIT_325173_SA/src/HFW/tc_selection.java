package HFW;

public class tc_selection {
	public String tcid,flag,test_data_sh;
	public int no_steps;
}
