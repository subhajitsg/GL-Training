package SDAY3;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class pgm3 {
	public static void main(String args[]) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();	//launch the browser
		dr.get("https://ultimateqa.com/simple-html-elements-for-automation/");
		dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		WebDriverWait wt=new WebDriverWait(dr,10);
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath("sdfs")));
		wt.until(ExpectedConditions.titleContains("Facebook"));
		dr.findElement(By.xpath("sdfs")).click();
		
	}
}
