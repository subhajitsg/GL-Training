/**
 * 
 */
package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * @author subhajit.ghosh
 *
 */
public class Fbdata {

	/**
	 * @param args
	 */
	public ArrayList<table> readexl(){
		ArrayList<table> tr=new ArrayList<table>();
		File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\Fbdb.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			for(int i=1;i<=2;i++) {
				table t=new table();
				XSSFRow r=sh.getRow(i);
				XSSFCell c=r.getCell(0);
				t.name=c.getStringCellValue();
				
				XSSFCell c1=r.getCell(1);
				t.email=c1.getStringCellValue();
				
				XSSFCell c2=r.getCell(2);
				t.password=c2.getStringCellValue();
				
				tr.add(t);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tr;
	}
	public void getdata(ArrayList<table> tr) {
		File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\Fbdb.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();	//launch the browser
		dr.get("https://www.facebook.com");
		dr.findElement(By.name("email")).sendKeys("subhajit.chikky@gmail.com");
		dr.findElement(By.name("pass")).sendKeys("741852963");
		
		dr.findElement(By.id("loginbutton")).click();
		String s=dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span")).getText();
		if(s.equals("Subhajit")) {
			System.out.println("Successful");
		}else {
			System.out.println("Unsuccessful");
		}
	}

}
