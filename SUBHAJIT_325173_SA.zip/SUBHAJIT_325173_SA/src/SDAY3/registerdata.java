package SDAY3;

public class registerdata {
	String fname,lname,email,gender,pass,conpass;
}
