package SDAY3;

public class logindata {
	String uid,pwd,ex_res,actual_res,test_res;
	
}
