package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {
	static logindata test;
	public static logindata read_excel() {
		logindata data=new logindata();
		File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\logindata.xlsx");
		
			FileInputStream fis;
			try {
				fis = new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow r=sh.getRow(1);
				XSSFCell c=r.getCell(0);
				data.uid=c.getStringCellValue();
				
				XSSFCell c1=r.getCell(1);
				data.pwd=c1.getStringCellValue();
				
				XSSFCell c2=r.getCell(2);
				data.ex_res=c2.getStringCellValue();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return data;
	}

	public static void login() {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();	//launch the browser
		dr.get("http://demowebshop.tricentis.com/login");
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(test.uid);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(test.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		String e=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		if(e.equals("subhajit.chikky@gmail.com")) {
			test.actual_res="SUCCESS";
		}else {
			test.actual_res="FAILURE";
		}
	}
	public static void writeexcl() {
		File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\logindata.xlsx");
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.createCell(3);
			c.setCellValue(test.actual_res);
			
			XSSFCell actual=r.getCell(3);
			String y=actual.getStringCellValue();
			XSSFCell c1=r.getCell(2);
			String x=c1.getStringCellValue();
			if(y.equals(x)) {
				XSSFCell c2=r.createCell(4);
				c2.setCellValue("PASS");
			}else {
				XSSFCell c2=r.createCell(4);
				c2.setCellValue("FAIL");
			}
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test=read_excel();
		login();
		writeexcl();
		
		
	}

}
