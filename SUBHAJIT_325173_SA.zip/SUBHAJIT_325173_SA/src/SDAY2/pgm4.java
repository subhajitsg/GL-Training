package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();	//launch the browser
		dr.get("https://www.w3schools.com/html/html_tables.asp");
		int r,c;
		for(r=2;r<=7;r++) {
			for(c=1;c<=3;c++) {
				String s2=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr["+r+"]/td["+c+"]")).getText();
				System.out.print(s2 +" ");
			}
			System.out.println();
		}
	}
}


