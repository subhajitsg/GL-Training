package Assignment;

public class registerdata {
	public String fname,lname,email,gender,pass,conpass;

}
