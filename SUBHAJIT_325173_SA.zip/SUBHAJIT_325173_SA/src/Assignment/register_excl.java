package Assignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;




public class register_excl {
	public static registerdata test;
	String name;
	public String readexcl(int r, int v) {
		//registerdata da=new registerdata();
		
		
		try {
			File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\registerauto.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			
				XSSFRow ri= sh.getRow(r);
				
				XSSFCell c1=ri.getCell(v);
				name=c1.getStringCellValue();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;
		
	}
	public void writeexcl(int fla,int ro, int v) {
		File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\registerauto.xlsx");
		String s="Success";
		String y="Fail";
		try {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			XSSFRow r=sh.getRow(ro);
			XSSFCell c=r.createCell(v);
			if(fla==1)
			c.setCellValue(s);
			else
				c.setCellValue(y);
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}

	/*public static void registration() {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();	//launch the browser
		dr.get("http://demowebshop.tricentis.com");
		String title=dr.getTitle();
		if(title.equals("Demo Web Shop")) {
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
			String title1=dr.getTitle();
			if(title1.equals("Demo Web Shop. Register")) {
				
				dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(test.fname);
				dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(test.lname);
				dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(test.email);
				if(test.gender.equals("Male")) {
					
						dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
				}
				else {
					
						dr.findElement(By.xpath("//*[@id=\"gender-female\"]")).click();
				}
				dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(test.pass);
				dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(test.conpass);
				dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
				String res=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
				if(res.equals(test.email)) {
					System.out.println("Registration Successful");
				}else {
					System.out.println("Registration Unsuccessful");
				}
			}
			else {
				System.out.println("Wrong WebPage");
			}
		}else {
			System.out.println("Wrong WebPage");
		}
}
}*/
