package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class webelements {
WebDriver dr;
	
	webelements(WebDriver dr){
		this.dr=dr;
	}
	
	public void enter_txt(String xp, String data) {
		dr.findElement(By.xpath(xp)).sendKeys(data);
		}
	
	public void radio(String xp, String data) {
		if(data.equals("Male")) {
			
			dr.findElement(By.xpath(xp)).click();
	}
		else if(data.equals("Female")) {
		
			dr.findElement(By.xpath(xp)).click();
	}
	}
	
	public void click(String xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	public int verify(String xp, String data) {
		String s;
		int flag=0;
		s=dr.findElement(By.xpath(xp)).getText();
		if(s.equals(data)) {
			System.out.println("Successfully Logged in");
			flag=1;
		}
		
		else {
			System.out.println("Registration not completed");
		}
		return flag;
	}
	/*public void closebr() {
		dr.close();
	}*/
	
	public void launchChrome(String url) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}
}
