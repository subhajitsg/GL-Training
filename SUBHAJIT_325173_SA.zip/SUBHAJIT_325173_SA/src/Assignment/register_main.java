package Assignment;

import org.openqa.selenium.WebDriver;



public class register_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kw, loc,td;
		WebDriver dr=null;
		webelements we=new webelements(dr);
		register_excl ex=new register_excl();
		for(int r=0;r<=14;r++) {
			kw=ex.readexcl(r,1);
			loc=ex.readexcl(r,2);
			td=ex.readexcl(r,3);
			switch(kw)
			{
			case "launchchrome" :
				we.launchChrome(td);
				break;
				
			case "enter_txt":
				we.enter_txt(loc,td);
				break;
				
			case "radio":
				we.radio(loc, td);
				break;
				
			case "verify":
				int x=we.verify(loc, td);
				ex.writeexcl(x, r, 4);
				break;
				
			/*case "closebr":
				we.closebr();
				break;*/
			case "click_btn":
				we.click(loc);
				break;
			}
		}
	}

}
