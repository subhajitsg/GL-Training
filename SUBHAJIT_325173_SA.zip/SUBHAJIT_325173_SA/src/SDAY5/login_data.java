package SDAY5;

public class login_data {
	public String uid,pwd,exp_res1,act_res1,test_res,status;
	public String exp_em1,exp_em2,act_em1,act_em2;
	
	public login_data(String uid, String pwd, String exp_res, String act_res,String test_res) {
		this.uid=uid;
		this.pwd=pwd;
		this.exp_res1=exp_res;
		this.act_res1=act_res;
		this.test_res=test_res;
	}

	public login_data() {
		// TODO Auto-generated constructor stub
	}
}
