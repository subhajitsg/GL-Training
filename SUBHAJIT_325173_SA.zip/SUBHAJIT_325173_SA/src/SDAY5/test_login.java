package SDAY5;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test_login extends excel_io {
	
	public static ArrayList<login_data> login(ArrayList<login_data>arr) {
		for(login_data d:arr) {
				System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
				WebDriver dr=new ChromeDriver();
				dr.get("http://demowebshop.tricentis.com/login");
				
				dr.findElement(By.name("Email")).sendKeys(d.uid);
				dr.findElement(By.name("Password")).sendKeys(d.pwd);
				dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
				boolean f=dr.getTitle().contains("Login");
				if(!f) {
					d.act_res1="SUCCESS";
					System.out.println("Login Successfull");
					d.status="SUCCESS";
				}
				else {
					d.act_res1="FAILURE";
					d.act_em1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
					d.act_em2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
					System.out.println(d.exp_em1+"\n"+d.exp_em2);
				
				}
				if(d.exp_res1.equals("FAILURE")) {
					if(d.act_em1.equals(d.exp_em1)&&d.act_em2.equals(d.exp_em2)) {
							d.status="SUCCESS";
						
					}
					else
						d.status="FAILURE";
				}
			dr.close();	
			}
		return arr;
			}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0,ro=1;
		
		excel_io ex=new excel_io();
		ArrayList<login_data>arr=ex.get_test_data();
		ArrayList<login_data>a1=login(arr);
		for(login_data d:a1) {
			System.out.println(d.act_em1);
			System.out.println(d.act_em2);
			System.out.println(d.act_res1);
			System.out.println(d.status);
		}
		ex.write_excel(a1);
		
		
	}

}
