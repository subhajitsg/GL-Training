package SDAY5;

import org.testng.annotations.Test;

public class NewTest {
	//In testNG class there is no main
	//we don't create object of class
	//no calling of function
  @Test
  public void t1() {
	  System.out.println("In test t1");
	  t2();
  }
  
  
  public void t2() {
	  System.out.println("In test t2");
	  t3();
  }
  @Test
  public void t3() {
	  System.out.println("In test t3");
  }
}
