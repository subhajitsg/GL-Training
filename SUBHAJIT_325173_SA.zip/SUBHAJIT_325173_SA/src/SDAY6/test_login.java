package SDAY6;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test_login extends excel_io {
	
	public static login_data login(login_data ldata) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();	//launch the browser
		dr.get("http://demowebshop.tricentis.com/login");
		
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(ldata.uid);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(ldata.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		boolean f=dr.getTitle().contains("Login");
		
		if(!f) {
			ldata.act_res1="SUCCESS";
			System.out.println("Login Success");
		}
		else {
			ldata.act_res1="FAILURE";
			ldata.act_em1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			ldata.act_em2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			
		}
		if(ldata.exp_res1.equals(ldata.act_res1)) 
		{
			
		if(ldata.exp_res1.equals("FAILURE")) 
		{
			if((ldata.exp_em1.equals(ldata.act_em1))&&(ldata.exp_em2.equals(ldata.act_em2))) 
			{
				ldata.test_res="PASS";
			}else {
				ldata.test_res="FAIL";
			}
		
		}
		else {
			ldata.test_res="PASS";
			dr.findElement(By.xpath("//a[@href='/logout']")).click();  
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			dr.close();
		}
		}
		else {
			ldata.test_res="FAIL";
		}
		return ldata;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0,ro=1;
		data_al=new ArrayList<login_data>();
		get_test_data();
		
		for(login_data ld:data_al) {
			login_data ld1=login(ld);
			data_al.set(c, ld1);
			write_excel(ro,ld1);
			c++;
			ro++;
		}
		
	}

}
