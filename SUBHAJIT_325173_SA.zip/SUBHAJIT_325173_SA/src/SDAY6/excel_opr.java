package SDAY6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class excel_opr {
	String name;
	public String read_excel(int r, int v) {
		
		File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\logictest.xlsx");
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
				XSSFRow ri= sh.getRow(r);
				
				XSSFCell c1=ri.getCell(v);
				name=c1.getStringCellValue();
				
				
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;

}
}
