package SDAY6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest3 {
	test_login loginob;
	login_data ldata,ldata_out;
	@BeforeClass
	public void config() {
		 ldata=new login_data();
		  ldata_out=new login_data();
		  loginob=new test_login();
	}
  @Test(dataProvider="security")
  public void login_test1(String u, String p, String exp_res) {
	 System.out.println("Login: "+u+" "+p);
	  ldata.uid=u;
	  ldata.pwd=p;
	  ldata.exp_res1=exp_res;
	  ldata.exp_em1="Login was unsuccessful. Please correct the errors and try again";
	  ldata.exp_em2="The credentials provided are incorrect";
	  ldata_out=loginob.login(ldata);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ldata_out.act_res1, ldata_out.exp_res1);
	  sa.assertAll();
  }
  
  @DataProvider(name="security")
  public String[][] getdata(){
	  String [][]data= {{"subhajit.chikky@gmail.com","chikky1997","SUCCESS"},{"subhajit.chikky@gmail.com","hgchgcgchc","FAILURE"}};
	  return data;
  }
}
