package SDAY6;

import org.openqa.selenium.WebDriver;

public class driver_script {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kw, loc,td;
		WebDriver dr=null;
		all_webelement_fns we=new all_webelement_fns(dr);
		excel_opr ex=new excel_opr();
		for(int r=1;r<=4;r++) {
			kw=ex.read_excel(r,3);
			loc=ex.read_excel(r,4);
			td=ex.read_excel(r,5);
			switch(kw)
			{
			case "launchchrome" :
				we.launchChrome(td);
				break;
				
			case "enter_text":
				we.enter_txt(loc,td);
				break;
				
			case "click_btn":
				we.click(loc);
				break;
			}
		}
	}

}

