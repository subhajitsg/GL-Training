package SDAY6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;



public class NewTest1 {
	test_login loginob;
	login_data ldata,ldata_out;
  @Test
  public void t1() {
	  ldata=new login_data();
	  ldata_out=new login_data();
	  loginob=new test_login();
	  
	  ldata.uid="subhajit.chikky@gmail.com";
	  ldata.pwd="chikky1997";
	  ldata.exp_res1="SUCCESS";
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ldata_out.act_res1, ldata_out.exp_res1);
	  sa.assertAll();
	  ldata_out=loginob.login(ldata);
	  System.out.println("ldata_out.act_res1: "+ldata_out.act_res1);
  }
  
  @Test
  public void t2() {
	  ldata=new login_data();
	  ldata_out=new login_data();
	  loginob=new test_login();
	  
	  ldata.uid="subhajit.chikky@gmail.com";
	  ldata.pwd="erjwkrwk";
	  ldata.exp_res1="SUCCESS";
	  ldata.exp_em1="Login was unsuccessful. Please correct the errors and try again";
	  ldata.exp_em2="The credentials provided are incorrect";
	  
	  ldata_out=loginob.login(ldata);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ldata_out.act_res1, ldata_out.exp_res1);
	  
	  System.out.println("ldata_out.act_res1: "+ldata_out.act_res1);
	  sa.assertAll();
  }
}



