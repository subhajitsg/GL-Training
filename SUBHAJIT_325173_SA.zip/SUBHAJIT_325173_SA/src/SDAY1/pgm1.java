package SDAY1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();	//launch the browser
		dr.get("https://www.facebook.com");
		dr.findElement(By.name("email")).sendKeys("subhajit.chikky@gmail.com");
		dr.findElement(By.name("pass")).sendKeys("741852963");
		
		dr.findElement(By.id("loginbutton")).click();
		
		
		
		
		
	}

}
