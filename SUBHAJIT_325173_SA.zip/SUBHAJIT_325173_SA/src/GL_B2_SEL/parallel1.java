package GL_B2_SEL;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class parallel1 {
	
	WebDriver dr;
	String autURL, nodeURL;
	
	@Test
	public void test1() throws MalformedURLException{
		autURL="https://www.facebook.com";
		nodeURL="http:///172.16.135.171:5566/wd/hub";
		DesiredCapabilities cap= DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.WINDOWS);
		dr=new RemoteWebDriver(new URL(nodeURL), cap);
		dr.get("https://www.facebook.com");
	}
	
	@Test
	public void test2() {
		autURL="https://www.facebook.com";
		nodeURL="http:///172.16.135.173:5566/wd/hub";
		DesiredCapabilities cap= DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.WINDOWS);
		try {
			dr=new RemoteWebDriver(new URL(nodeURL), cap);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.get("https://www.facebook.com");
	}
}
