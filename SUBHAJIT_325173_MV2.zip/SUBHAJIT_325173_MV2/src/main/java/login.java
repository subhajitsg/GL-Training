package main.java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class login {
	WebDriver dr;
	public login(WebDriver dr2) {
		this.dr=dr2;
	}
	public void login_page(String email, String password) {
		dr.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys(email);
		dr.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(password);
		dr.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]")).click();
	}
}
