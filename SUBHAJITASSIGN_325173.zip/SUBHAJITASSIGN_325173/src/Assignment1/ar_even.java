package Assignment1;

import java.util.ArrayList;

public class ar_even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> ir=new ArrayList<Integer>();
		int a[]=new int[30];
		int j=10;
		for(int i=0;i<20;i++) {
			a[i]=j;
			if(a[i]%2==0) {
				ir.add(a[i]);
			}
			j++;
		}
		for(int even : ir)
		System.out.println(even); 
	}

}
