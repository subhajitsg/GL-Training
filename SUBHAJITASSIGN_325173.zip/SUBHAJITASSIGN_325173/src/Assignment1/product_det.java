package Assignment1;

public class product_det {
	int pid;
	String pname;
	int unit_rate;
	int unit_price;
	int price;
	String grade;

	public void price() {
		this.price=unit_rate*unit_price;
	}

	public void grade(product_det p) {
		if(p.price<25000) {
			this.grade="GradeA";
		}
		else if (p.price>25000) {
			this.grade="GradeB";
		}
	}
}
