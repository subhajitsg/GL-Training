package Assignment1;

public class arms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = new int[10];
		int n,r1,sum = 0;
		int c=0;
		System.out.println("Armstrong numbers");
		for (int i=1;i<=1000;i++)
		{
			n=i;
			while(n>0)
			{
				r1=n%10;
				sum= sum+(r1*r1*r1);
				n=n/10;
			}
	 
			if(sum==i)
			{
				arr[c]=i;
				c++;
			}
			sum=0;
			
		}
		for(int i=0;i<5;i++) {
			System.out.println(arr[i]);
		}
	}

}
