package Assignment1;

public class student_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student s1=new student(1,"Manu",90,91);
		student s2=new student(2,"Anupam",92,98);
		student s3=new student(3,"Santosh",91,99);
		s1.average();
		s2.average();
		s3.average();
		if(s1.avg>65) 
		{
		  System.out.println("Name : " + s1.name + "\nRoll No: " + s1.rollno + "\nJava Marks: " + s1.java + "\nSelenium Marks: "+ s1.selenium );
		}
		if(s2.avg>65) 
		{
		System.out.println("Name : " + s2.name + "\nRoll No: " + s2.rollno + "\nJava Marks: " + s2.java + "\nSelenium Marks: "+ s2.selenium );
		}
		if(s3.avg>65) 
		{
		System.out.println("Name : " + s3.name + "\nRoll No: " + s3.rollno + "\nJava Marks: " + s3.java + "\nSelenium Marks: "+ s3.selenium );	
		}
	}

}
