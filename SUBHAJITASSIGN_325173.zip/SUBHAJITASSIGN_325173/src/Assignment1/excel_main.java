package Assignment1;

import java.util.ArrayList;

public class excel_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<product_det> al = new ArrayList<product_det>();
		excl_operations ex1 = new excl_operations();
		al=ex1.read_excel();
		ex1.write_excel(al);
	}

}
