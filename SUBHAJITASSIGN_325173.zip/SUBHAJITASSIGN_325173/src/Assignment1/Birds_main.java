package Assignment1;

public class Birds_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parrots p1 = new Parrots(18,30,80,"Red","Fruits","Female","Cockatoo",2);
		Parrots p2 = new Parrots(62,48,40,"Yellow","Seeds","Male","Strigopidae",2);
		Parrots p3 = new Parrots(8,22,20,"Maroon","Insects","Female","Macaw",2);
		Owl o1 = new Owl(29,60,3,"White","Squirrels","Female","Eostrix",2);
		Owl o2= new Owl(17,30,4,"Black","Insects","Male","True owl",2);
		
		p1.display();
		p1.eats();
		p1.flys();
		p2.display();
		p2.simulate();
		p2.flys();
		p3.display();
		p3.eats();
		p3.shouts();
		
		o1.display();
		o1.eats();
		o1.neck_rotate();
		o1.vision();
		o2.display();
		o2.hunts();
	}
}


