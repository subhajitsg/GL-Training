package Assignment1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excl_operations {
	public ArrayList<product_det> read_excel() {

		ArrayList<product_det> std_al = new ArrayList<product_det> ();
		for(int i=1;i<=3;i++) {
			try {
				product_det p = new product_det();
				File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\Product.xlsx");
				FileInputStream fis = new FileInputStream(f);
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet("Sheet1");
				XSSFRow r = sh.getRow(i);

				XSSFCell c = r.getCell(0);
				p.pid = (int) c.getNumericCellValue();

				XSSFCell c1 = r.getCell(1);
				p.pname = c1.getStringCellValue();


				XSSFCell c2 = r.getCell(2);
				p.unit_rate = (int) c2.getNumericCellValue();

				XSSFCell c3 = r.getCell(3);
				p.unit_price = (int) c3.getNumericCellValue();

				p.price();
				p.grade(p);
				std_al.add(p);

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return std_al;

	}

	public void write_excel(ArrayList<product_det> std_al) {

		try {

			int row=1;
			File f=new File("C:\\Users\\subhajit.ghosh\\Desktop\\Training\\Product.xlsx");

			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			for(product_det p: std_al) {
				XSSFRow r = sh.getRow(row);

				XSSFCell c = r.createCell(4);
				c.setCellValue((double)p.price);
				XSSFCell c1 = r.createCell(5);
				c1.setCellValue(p.grade);

				FileOutputStream fos = new FileOutputStream(f);
				wb.write(fos);
				row++;
			}
		}

		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();

		}
	}
}
