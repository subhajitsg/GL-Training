package Assignment1;

public class Parrots extends Birds {
	int leng;
	int mass;
	
	public void simulate() {
		System.out.println("Parrot simulate voice");
	}
	public void found() {
		System.out.println("Parrot usually found in tropical and subtropical region");
	}
	public void shouts() {
		System.out.println("Parrot makes noise");
	}
	
	
	public Parrots(int leng, int mass, int age, String color, String food, String gender, String name, int nol) {
		// TODO Auto-generated constructor stub
		
		this.food=food;
		this.gender=gender;
		this.name=name;this.leng=leng;
		this.mass=mass;
	    this.age=age;
		this.color=color;
		this.nol=nol;
	}


	public void display() {
		System.out.println("Name: "+this.name +"\nNo of legs: " +this.nol + "\nSkin color: "+ this.color + "\nFood: " + this.food + "\nGender: " + this.gender + "\nAge: " + this.age );
		
		System.out.println("Length of trunk : "+ this.leng + "\nLength of tusks: " + this.mass);
	}
}
