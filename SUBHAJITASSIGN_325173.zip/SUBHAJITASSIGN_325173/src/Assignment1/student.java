package Assignment1;

public class student {
	public int rollno;
	public String name;
	public int java;
	public int selenium;
	public float avg;
	
	public student(int rollno,String name,int java,int selenium) {
		this.name=name;
		this.rollno=rollno;
		this.java=java;
		this.selenium=selenium;
	}
	
	public void average() 
	{
		this.avg=(float)(this.java+this.selenium)/2.0f;
	}

	
}
