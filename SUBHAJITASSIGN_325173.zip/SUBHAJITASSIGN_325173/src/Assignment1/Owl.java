package Assignment1;

public class Owl extends Birds {
	int leng;
	int mass;
	
	public void neck_rotate() {
		System.out.println("Owl rotates neck 270 degrees");
	}
	

	public void hunts() {
		System.out.println("Owl hunts other Owls");
	}
	public void vision(){
		System.out.println("Owl have binocular vision");
	}
	
	
		
		
	public Owl(int leng, int mass,int age, String color, String food, String gender, String name, int nol) {
		// TODO Auto-generated constructor stub
		this.leng=leng;
		this.mass=mass;
		this.age=age;
		this.color=color;
		this.food=food;
		this.gender=gender;
		this.name=name;
		this.nol=nol;
	}


	public void display() {
		System.out.println("Name: "+this.name+" No of legs: " +this.nol + " Skin color: "+ this.color + " Food: " + this.food   
							+ " Gender: " + this.gender + " Age: " + this.age );
		
		System.out.println("Length of teeth : "+ this.leng + " Length of claws : " + this.mass);
	}
}
